"use client";

import { useState, useEffect } from "react";

interface Particle {
  id: number;
  x: number;
  delay: number;
  size: number;
  emoji: string;
  duration: number;
}

const EMOJIS = ["❤️", "💖", "💕", "🌸", "✨", "💗", "🌹", "💝"];

export default function FloatingParticles() {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.65) {
        const newParticle: Particle = {
          id: Date.now() + Math.random(),
          x: Math.random() * (typeof window !== "undefined" ? window.innerWidth : 1000),
          delay: Math.random() * 2,
          size: Math.random() * 16 + 12,
          emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
          duration: 4 + Math.random() * 3,
        };
        setParticles((prev) => [...prev.slice(-12), newParticle]);
      }
    }, 1800);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((p) => (
        <div
          key={p.id}
          className="heart-particle absolute"
          style={{
            left: p.x,
            bottom: "-50px",
            fontSize: p.size,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
          }}
        >
          {p.emoji}
        </div>
      ))}
    </div>
  );
}
